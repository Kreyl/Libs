#pragma once

#include <cstdint>

int16_t cosineFromZeroToHalfPi(uint16_t numerator, uint16_t denominator);
